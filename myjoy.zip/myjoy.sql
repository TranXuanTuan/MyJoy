-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2019 at 04:53 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myjoy`
--

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `artist_id` bigint(20) UNSIGNED NOT NULL,
  `album_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`id`, `category_id`, `artist_id`, `album_name`, `thumb`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Bạc Phận', 'Nhớ Không Em', NULL, NULL),
(2, 2, 1, '\r\nHola Senõrita', 'Tiểu Dragon', NULL, NULL),
(3, 3, 1, 'Hãy Trao Cho Anh', 'Tiểu Dragon', NULL, NULL),
(4, 4, 1, 'Hết Thương Cạn Nhớ', 'Tiểu Dragon', NULL, NULL),
(5, 5, 1, 'Là Bạn Không Thể Quên', 'Tiểu Dragon', NULL, NULL),
(6, 1, 2, 'Sóng Gió', 'Nhớ Không Em', NULL, NULL),
(7, 2, 2, 'Ready For The Victory', 'Tiểu Dragon', NULL, NULL),
(8, 3, 2, 'Hãy Trao Cho Anh', 'Tiểu Dragon', NULL, NULL),
(9, 4, 2, 'Hết Thương Cạn Nhớ', 'Tiểu Dragon', NULL, NULL),
(10, 5, 2, 'Là Bạn Không Thể Quên', 'Tiểu Dragon', NULL, NULL),
(26, 1, 6, 'Lời Yêu Ngây Dại', 'Nhớ Không Em', NULL, NULL),
(27, 2, 6, 'Minecraft - Volume Alpha (CD1)', 'Tiểu Dragon', NULL, NULL),
(28, 3, 6, 'Hãy Trao Cho Anh', 'Tiểu Dragon', NULL, NULL),
(29, 4, 6, 'Hết Thương Cạn Nhớ', 'Tiểu Dragon', NULL, NULL),
(30, 5, 6, 'Là Bạn Không Thể Quên', 'Tiểu Dragon', NULL, NULL),
(31, 1, 7, 'Người Ấy', 'Nhớ Không Em', NULL, NULL),
(32, 2, 7, 'Cơn mưa ngang qua', 'Tiểu Dragon', NULL, NULL),
(33, 3, 7, 'Hãy Trao Cho Anh', 'Tiểu Dragon', NULL, NULL),
(34, 4, 7, 'Hết Thương Cạn Nhớ', 'Tiểu Dragon', NULL, NULL),
(35, 5, 7, 'Là Bạn Không Thể Quên', 'Tiểu Dragon', NULL, NULL),
(36, 1, 8, 'Đếm Cừu', 'Nhớ Không Em', NULL, NULL),
(37, 2, 8, 'Cơn mưa ngang qua', 'Tiểu Dragon', NULL, NULL),
(38, 3, 8, 'Hãy Trao Cho Anh', 'Tiểu Dragon', NULL, NULL),
(39, 4, 8, 'Hết Thương Cạn Nhớ', 'Tiểu Dragon', NULL, NULL),
(40, 5, 8, 'Là Bạn Không Thể Quên', 'Tiểu Dragon', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `album_categories`
--

CREATE TABLE `album_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `album_categories`
--

INSERT INTO `album_categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 'POP', NULL, NULL),
(2, 'ROCK', NULL, NULL),
(3, 'RAP', NULL, NULL),
(4, 'EDM', NULL, NULL),
(5, 'GUITAR', NULL, NULL),
(6, 'PIANO', NULL, NULL),
(7, 'KOREAN', NULL, NULL),
(8, 'JAPAN', NULL, NULL),
(9, 'TEEN', NULL, NULL),
(10, 'DANCE', NULL, NULL),
(11, 'COUNTRY', NULL, NULL),
(12, 'VIOLIN', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE `artists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `artist_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intro` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `artists`
--

INSERT INTO `artists` (`id`, `category_id`, `artist_name`, `intro`, `thumb`, `created_at`, `updated_at`) VALUES
(1, 1, 'Sơn Tùng MT-P', 'Tuyển tập những ca khúc hay nhất của Sơn Tùng M-TP', 'sontungmtp.jpg', NULL, NULL),
(2, 1, 'Đức Phúc', 'Chàng trai Ballad Đức Phúc đã chính thức trở lại với “Hết Thương Cạn Nhớ”, ca khúc hứa hẹn sẽ chiếm trọn tình cảm của các fan. Chần chừ gì mà không nghe ngay tại Zing MP3!', 'ducphuc.png', NULL, NULL),
(3, 1, 'Soobin Hoàng Sơn', 'Cuối cùng thì “Hoàng tử ballad” ngày nào đã trở về với chất nhạc từng đốn “lụi tim” các fan của mình. Còn chần chờ gì nữa đây đại gia đình Susu, cùng nghe ngay ca khúc “Nếu Ngày Ấy” của Soobin\r\n', 'sbhoangson.jpg', NULL, NULL),
(4, 1, 'Jack', 'Sau bao trông ngóng từ các fan thì Jack và K-ICM đã chính thức trở lại cùng “Em Gì Ơi”, hứa hẹn sẽ tiếp tục là một bản hit trong thời gian sắp tới đây! Các Đóm và Keys ơi, cùng lắng nghe “Em Gì Ơi” ngay nào!', 'jack.jpg', NULL, NULL),
(5, 1, 'Lou Hoàng', 'Liệu khi đã là bạn bè, chúng ta có thể dành cho nhau một thứ tình cảm khác hay không? “Là Bạn Không Thể Yêu” sẽ lại là một câu chuyện mà chắc rằng rất nhiều fan sẽ đồng cảm với Lou Hoàng đấy!', 'louhoang.jpg', NULL, NULL),
(6, 2, 'Alan Walker', '', 'alanwaker.jpg', NULL, NULL),
(7, 2, 'Sia', '', 'Sia.jpg', NULL, NULL),
(8, 2, 'Camila', '', 'camila.jpg', NULL, NULL),
(9, 2, 'Lil Nas X', '', 'lilnas.jpg', NULL, NULL),
(10, 2, 'WestLife', '', 'westlife.jpg', NULL, NULL),
(11, 3, 'BTS', '', 'bts.jpg', NULL, NULL),
(12, 3, 'BlackPink', '', 'blackpink.jpg', NULL, NULL),
(13, 3, 'Twice', '', 'twice.jpg', NULL, NULL),
(14, 3, 'BigBang', '', 'bigbang.jpg', NULL, NULL),
(15, 3, 'T-Ara', '', 't-ara.jpg', NULL, NULL),
(16, 4, 'Hayashibara Megumi', '', 'HayashibaraMegumi.jpg', NULL, NULL),
(17, 4, 'Kenshi Yonezu', '', 'KenshiYonezu.jpg', NULL, NULL),
(18, 4, 'Teshima Aoi', '', 'TeshimaAoi.jpg', NULL, NULL),
(19, 4, 'Mai Kuraki', '', 'MaiKuraki.jpg', NULL, NULL),
(20, 4, 'Aimer', '', 'Aimer.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `artist_categories`
--

CREATE TABLE `artist_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `artist_categories`
--

INSERT INTO `artist_categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 'VietNam', NULL, NULL),
(2, 'US-UK', NULL, NULL),
(3, 'Korean', NULL, NULL),
(4, 'Japan', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `beats`
--

CREATE TABLE `beats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beats`
--

INSERT INTO `beats` (`id`, `category_id`, `author`, `picture`, `created_at`, `updated_at`, `content`, `price`) VALUES
(1, 1, 'Pham Toan Thang', NULL, NULL, NULL, 'Love', 15),
(2, 2, 'Lee Tieu Long', NULL, NULL, NULL, 'Sad', 15),
(3, 3, 'Justa Tee', NULL, NULL, NULL, 'Love', 15),
(4, 4, 'Buc Tuong', NULL, NULL, NULL, 'Sad', 15);

-- --------------------------------------------------------

--
-- Table structure for table `beat_categories`
--

CREATE TABLE `beat_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `beat_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `thumb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beat_categories`
--

INSERT INTO `beat_categories` (`id`, `beat_name`, `created_at`, `updated_at`, `thumb`) VALUES
(1, 'Young Music', NULL, NULL, NULL),
(2, 'Belero', NULL, NULL, NULL),
(3, 'R&B', NULL, NULL, NULL),
(4, 'Rock', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `song_id` bigint(20) UNSIGNED NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `menu_name`, `created_at`, `updated_at`) VALUES
(7, 'Album', '2019-10-06 03:14:57', '2019-10-06 06:26:13'),
(8, 'Subject', '2019-10-06 03:15:07', '2019-10-06 03:15:07'),
(9, 'Artist', '2019-10-06 03:15:14', '2019-10-06 03:15:14');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_02_040655_create_permission_tables', 1),
(4, '2019_08_02_042721_create_posts_table', 1),
(5, '2019_08_05_020225_create_verify_users_table', 1),
(6, '2019_08_14_064040_create_menus_table', 1),
(7, '2019_08_14_093212_create_sub_categories_table', 1),
(8, '2019_09_30_035718_add_fk_user_verifyuser_table', 1),
(9, '2019_10_02_025121_create_subjects_table', 1),
(10, '2019_10_02_035249_create_song_categories_table', 1),
(11, '2019_10_02_041019_create_songs_table', 1),
(12, '2019_10_02_041935_create_comments_table', 1),
(13, '2019_10_02_045933_create_artist_categories_table', 1),
(14, '2019_10_02_050334_create_album_categories_table', 1),
(15, '2019_10_02_050426_create_albums_table', 1),
(16, '2019_10_02_050452_create_artists_table', 1),
(17, '2019_10_02_072211_create_playlists_table', 1),
(18, '2019_10_02_072900_create_beat_categories_table', 1),
(19, '2019_10_02_073236_create_beats_table', 1),
(20, '2019_10_02_073718_create_receipts_table', 1),
(21, '2019_10_02_084653_add_fk_subject_song_category', 1),
(22, '2019_10_02_085946_add_fk_song_category_song', 1),
(23, '2019_10_02_090734_add_fk_song_comment', 1),
(24, '2019_10_02_091019_add_fk_album_category_album', 1),
(25, '2019_10_02_092153_add_fk_artist_category_artist', 1),
(26, '2019_10_02_092436_add_fk_artists_albums', 1),
(27, '2019_10_02_092615_add_fk_artists_songs', 1),
(28, '2019_10_02_092940_add_fk_beat_categories_beats', 1),
(29, '2019_10_02_093321_add_fk_beat_receipts', 1),
(30, '2019_10_02_093454_add_fk_users_receipts', 1),
(31, '2019_10_02_101724_add_fk_users_playlists', 1),
(32, '2019_10_02_101941_add_fk_playlists_songs', 1),
(33, '2019_10_08_123401_create_news_table', 2),
(34, '2019_10_19_084717_add_column_price_content_into_beats_table', 3),
(35, '2019_10_19_093404_add_column_thumb_into_beat_categories', 4);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(3, 'App\\User', 2),
(3, 'App\\User', 3);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `content`, `image`, `author`, `created_at`, `updated_at`) VALUES
(1, 'Lưu Hương Giang:Chúng tôi đã ly hôn khi mất phương hướng', 'Lưu Hương Giang chia sẻ cô và Hồ Hoài Anh đã mâu thuẫn, mất phương hướng, dẫn đến ly hôn.', 'Lưu Hương Giang và Hồ Hoài Anh ly hôn từ tháng 6. Thông tin hai nghệ sĩ chia tay sau hơn 10 năm gắn bó khiến nhiều khán giả tiếc nuối. Tối 7/10, đại diện của nữ ca sĩ xác nhận chuyện ly hôn là có thật.', NULL, 'Admin', NULL, NULL),
(2, 'Hậu trường chụp ảnh nội y của vợ chồng Justin Bieber', 'Mới đây, một số hình ảnh hậu trường buổi chụp quảng cáo nội y của Justin và Hailey Bieber đã bị rò rỉ trên mạng. Cách tạo dáng nhạy cảm của hai vợ chồng khiến khán giả chú ý.', 'Đám cưới của Justin và Hailey Bieber vừa được tổ chức vào ngày 30/9 (giờ Mỹ). 5 ngày sau đó, đôi vợ chồng trẻ xuất hiện nóng bỏng trong bộ ảnh quảng cáo của một thương hiệu nội y nổi tiếng.', NULL, 'Admin', NULL, NULL),
(3, 'Clip ngắn của Sơn Tùng M-TP cán mốc hơn 8 triệu view sau 24 giờ', 'Sơn Tùng M-TP luôn là cái tên sở hữu lượng fan lớn của Vpop, clip ngắn mới đây của anh nhanh chóng cán mốc hơn 8 triệu lượt xem cùng hàng nghìn bình luận sau 24 giờ.', 'Sau khi tung teaser và hình ảnh hậu trường gây tò mò, đoạn clip ngắn có sự xuất hiện của Sơn Tùng M-TP đã chính thức công bố. Clip được nam ca sĩ chia sẻ trên trang cá nhân và nhận được hơn 5.000 bình luận, hầu hết đều khen ngợi vẻ điển trai của “sếp”.', NULL, 'Admin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Administer roles & permissions', 'web', '2019-10-03 22:08:12', '2019-10-03 22:08:12'),
(2, 'Create Post', 'web', '2019-10-03 22:08:19', '2019-10-03 22:08:19'),
(3, 'Edit Post', 'web', '2019-10-03 22:08:25', '2019-10-03 22:08:25'),
(4, 'Delete Post', 'web', '2019-10-03 22:08:35', '2019-10-03 22:08:35'),
(5, 'View', 'web', '2019-10-21 01:15:29', '2019-10-21 01:15:29');

-- --------------------------------------------------------

--
-- Table structure for table `playlists`
--

CREATE TABLE `playlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `song_id` bigint(20) UNSIGNED NOT NULL,
  `playlist_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Hãy Trao Cho Anh- Sơn Tùng MT-P', '123', '2019-10-03 22:09:50', '2019-10-03 22:09:50'),
(2, 'Để Mị Nói Cho Mà Nghe- Hoàng Thùy Linh', '123', '2019-10-06 04:44:34', '2019-10-06 04:44:34'),
(3, 'Mơ- Vũ Cát Tường', '11', '2019-10-06 04:44:48', '2019-10-06 04:44:48'),
(4, 'Canh Bao', '15', '2019-10-06 04:45:00', '2019-10-06 04:45:00'),
(5, 'Simple love', '44', '2019-10-06 04:45:17', '2019-10-06 04:45:17'),
(6, 'Anh di tim e', 'yy', '2019-10-06 04:45:47', '2019-10-06 04:45:47'),
(7, 'Noi Nho day voi', 'noo', '2019-10-06 04:46:58', '2019-10-06 04:46:58');

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `beat_id` bigint(20) UNSIGNED NOT NULL,
  `date_buy` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'web', '2019-10-03 22:08:49', '2019-10-03 22:08:49'),
(2, 'User', 'web', '2019-10-21 01:15:05', '2019-10-21 01:15:05'),
(3, 'User VIP', 'web', '2019-10-21 01:16:13', '2019-10-21 01:16:13');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(2, 3),
(3, 1),
(3, 3),
(4, 1),
(5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `song_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `artist_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `artist_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mv` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`id`, `song_name`, `picture`, `artist_id`, `category_id`, `artist_name`, `link`, `mv`, `created_at`, `updated_at`) VALUES
(1, 'Hay Trao Cho Anh', 'sontungmtp.jpg', 1, 46, 'Son Tung MT-P', 'HayTraoChoAnh-SonTungMTPSnoopDogg-6010660.mp3', NULL, NULL, NULL),
(2, 'Faded', 'alanwaker.jpg', 6, 48, 'Alan Walker', 'Faded-AlanWalker-5919763.mp3', NULL, NULL, NULL),
(3, 'Let Kill This Love', 'blackpink.jpg', 12, 47, 'Black Pink', 'KillThisLove-BlackPink-5935546.mp3', NULL, NULL, NULL),
(4, 'ToSuBaSa', 'TeshimaAoi.jpg', 18, 49, 'Tesh', 'Bravery-AoiShoutaToshikiMasudaDaikiYamashitaNatsukiHanaeSomaSaitoYuichiroUmehara-5044347.mp3', NULL, NULL, NULL),
(5, 'Tieu Thuyet Tinh Yeu', NULL, 9, 50, 'Lee7,Andree,It\'s Lee', 'Tieuthuyettinhyeu-Lee7_482u.mp3', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `song_categories`
--

CREATE TABLE `song_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `song_categories`
--

INSERT INTO `song_categories` (`id`, `subject_id`, `category_name`, `created_at`, `updated_at`) VALUES
(46, 11, 'V-pop highlights', NULL, NULL),
(47, 12, 'K-pop highlights', NULL, NULL),
(48, 13, 'US-UK highlights', NULL, NULL),
(49, 14, 'C-Pop highlights', NULL, NULL),
(50, 15, 'VietRap highlights', NULL, NULL),
(51, 16, 'Rap', NULL, NULL),
(52, 17, 'Golden Music', NULL, NULL),
(53, 18, 'Love Story', NULL, NULL),
(54, 19, 'EDM', NULL, NULL),
(55, 20, 'Travel', NULL, NULL),
(56, 21, 'Relax', NULL, NULL),
(57, 22, 'VietPOP', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`, `created_at`, `updated_at`) VALUES
(11, 'Hot', NULL, NULL),
(12, 'Hit', NULL, NULL),
(13, 'K-Pop Hit', NULL, NULL),
(14, 'EDM', NULL, NULL),
(15, 'Acoustic', NULL, NULL),
(16, 'Indie', NULL, NULL),
(17, 'Bolero', NULL, NULL),
(18, 'Love', NULL, NULL),
(19, 'Party', NULL, NULL),
(20, 'Travel', NULL, NULL),
(21, 'Relax', NULL, NULL),
(22, 'V-Pop Hit', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `sub_menu_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `sub_menu_name`, `menu_id`, `created_at`, `updated_at`) VALUES
(7, 'OFFER', '8', '2019-10-06 03:18:27', '2019-10-06 03:18:27'),
(8, 'CATEGORY', '8', '2019-10-06 03:18:39', '2019-10-06 03:18:39'),
(9, 'MOOD', '8', '2019-10-06 03:18:54', '2019-10-06 03:18:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `avatar`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `verified`) VALUES
(1, NULL, 'TUN', 'tranxuantuan2909@gmail.com', NULL, NULL, '$2y$10$/otzV4lT1nhTKSdciQkeF.GHg2ftGU5/7kguDbO0X1AguIJJXG1AW', NULL, '2019-10-03 22:06:54', '2019-10-03 22:07:33', 1),
(2, NULL, 'Hoang', 'hoang3108@gmail.com', NULL, NULL, '$2y$10$0kMCAmLcs7c37cb.HwtqcukW6P5OzEqVk4YrywjuGX.dvPxwASrZW', NULL, '2019-10-21 01:31:37', '2019-10-21 01:31:37', 1),
(3, NULL, 'Zu~', 'vudinh@gmail.com', NULL, NULL, '$2y$10$z0BNYv69vdrURVX3dGU3DutZPtIAXEXorg.YOqpnYISSJo1Y2RpN.', NULL, '2019-10-21 01:35:46', '2019-10-21 01:35:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `verify_users`
--

CREATE TABLE `verify_users` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verify_users`
--

INSERT INTO `verify_users` (`user_id`, `token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'nMuLYxTXUqTJXtYBwZ2JgZZXXTT7YUN4DRRS9DQB', '2019-10-03 22:06:54', '2019-10-03 22:06:54', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`id`),
  ADD KEY `albums_category_id_foreign` (`category_id`),
  ADD KEY `albums_artist_id_foreign` (`artist_id`);

--
-- Indexes for table `album_categories`
--
ALTER TABLE `album_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `artists`
--
ALTER TABLE `artists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `artists_category_id_foreign` (`category_id`);

--
-- Indexes for table `artist_categories`
--
ALTER TABLE `artist_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beats`
--
ALTER TABLE `beats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `beats_category_id_foreign` (`category_id`);

--
-- Indexes for table `beat_categories`
--
ALTER TABLE `beat_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_song_id_foreign` (`song_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `playlists`
--
ALTER TABLE `playlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `playlists_user_id_foreign` (`user_id`),
  ADD KEY `playlists_song_id_foreign` (`song_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD KEY `receipts_beat_id_foreign` (`beat_id`),
  ADD KEY `receipts_user_id_foreign` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `songs_category_id_foreign` (`category_id`),
  ADD KEY `songs_artist_id_foreign` (`artist_id`);

--
-- Indexes for table `song_categories`
--
ALTER TABLE `song_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `song_categories_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `verify_users`
--
ALTER TABLE `verify_users`
  ADD KEY `verify_users_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `albums`
--
ALTER TABLE `albums`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `album_categories`
--
ALTER TABLE `album_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `artists`
--
ALTER TABLE `artists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `artist_categories`
--
ALTER TABLE `artist_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `beats`
--
ALTER TABLE `beats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `beat_categories`
--
ALTER TABLE `beat_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `playlists`
--
ALTER TABLE `playlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `songs`
--
ALTER TABLE `songs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `song_categories`
--
ALTER TABLE `song_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `albums`
--
ALTER TABLE `albums`
  ADD CONSTRAINT `albums_artist_id_foreign` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `albums_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `album_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `artists`
--
ALTER TABLE `artists`
  ADD CONSTRAINT `artists_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `artist_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `beats`
--
ALTER TABLE `beats`
  ADD CONSTRAINT `beats_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `beat_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_song_id_foreign` FOREIGN KEY (`song_id`) REFERENCES `songs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `playlists`
--
ALTER TABLE `playlists`
  ADD CONSTRAINT `playlists_song_id_foreign` FOREIGN KEY (`song_id`) REFERENCES `songs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `playlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `receipts`
--
ALTER TABLE `receipts`
  ADD CONSTRAINT `receipts_beat_id_foreign` FOREIGN KEY (`beat_id`) REFERENCES `beats` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `receipts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `songs`
--
ALTER TABLE `songs`
  ADD CONSTRAINT `songs_artist_id_foreign` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `songs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `song_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `song_categories`
--
ALTER TABLE `song_categories`
  ADD CONSTRAINT `song_categories_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `verify_users`
--
ALTER TABLE `verify_users`
  ADD CONSTRAINT `verify_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
